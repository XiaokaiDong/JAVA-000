
public interface TransformStrategy {
    void transform(byte[] in, int length);
}
